jQuery(document).ready(function( $ ) {

    $('.counter').counterUp({
        delay: 10,
        time: 1000
    });

    $('.team').owlCarousel({
	    loop:true,
	    margin:0,
		autoplay:true,
	    nav:false,
		dost:true,
		smartSpeed:1000,
	    responsive:{
	        0:{
	            items:1
	        },
	        600:{
	            items:1
	        },
	        1000:{
	            items:1
	        }
	    }
	});
    

    $('body').scrollspy({target: ".navbar", offset: 80});   
	  $(".menu a, .down-btn a").on('click', function(event) {
	    if (this.hash !== "") {
	      event.preventDefault();
	      var hash = this.hash;

	      $('html, body').animate({
	        scrollTop: $(hash).offset().top
	      }, 1000, function(){
	       
	      });
	    }  
	  });


	$('.isotop-item').isotope({
	    itemSelector: '.item',
	    LayoutMode: 'fitRows'
	});
	$('.isotop ul li').on('click', function(e){
	    $('.isotop ul li').removeClass('active');
	    $(this).addClass('active');
	    
	    var selector = $(this).attr('data-filter');
	    $('.isotop-item').isotope({
	        filter: selector
	    });
	    return false;
	});

	$('.isotop-oveley > a').magnificPopup({type:'image'});



	$('.scrolltop').on('click', function(e){
		$('html').animate({
			'scrollTop':0
		},1000);
		return false;
	});
	$(window).scroll(function(e){
	    var halcyan = $(window).scrollTop();
	    if(halcyan>400){
	        $('.scrolltop').slideDown(1000);
	    }
	    else{
	        $('.scrolltop').slideUp(1000);
	    }

	});

	$(window).scroll(function(){
	    var halcyan = $(window).scrollTop();
	    if(halcyan>0){
	        $('.header-top-area').addClass('header-top-sticky');
	    }
	    else{
	        $('.header-top-area').removeClass('header-top-sticky');
	    }

	});


	$(window).on('load', function(){
        $('#preloder').delay(200).fadeOut(2000);
        $('.sk-three-bounce').fadeOut(1000);
    });

    
});